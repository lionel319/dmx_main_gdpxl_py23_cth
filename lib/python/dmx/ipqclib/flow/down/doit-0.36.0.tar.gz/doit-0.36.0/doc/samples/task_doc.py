def task_hello():
    return {
        'actions': ['echo hello'],
        'doc': 'say hello',
    }
