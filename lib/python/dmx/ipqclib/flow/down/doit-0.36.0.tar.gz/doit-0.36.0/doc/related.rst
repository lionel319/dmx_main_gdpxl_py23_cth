.. meta::
   :description: Related Projects - task runner, build tool & pipelines
   :keywords: python, doit, task-runner, build-tool, pipeline, workflow

.. title:: Related Projects - task runner, build tool & pipelines

================
Related Projects
================

These are the main build tools in use today.

 - `make <http://www.gnu.org/software/make/>`_
 - `ant <http://ant.apache.org/>`_
 - `SCons <http://www.scons.org/>`_
 - `Rake <http://rake.rubyforge.org/>`_

There are `many <http://en.wikipedia.org/wiki/List_of_build_automation_software>`_ more...

In this `post <http://schettino72.wordpress.com/2008/04/14/doit-a-build-tool-tale/>`_ I briefly explained my motivation to start another build tool like project.

