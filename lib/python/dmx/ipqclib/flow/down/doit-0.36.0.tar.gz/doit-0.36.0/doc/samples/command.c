#include <stdio.h>

void command(int a){
  printf("geez");
};
