def task_unittest():
    return {
        'actions': ['echo unit-test'],
        'meta': {'tags': ['test']},
        }
