def task_python_version():
    return {
        'actions': [['python', '--version']]
        }

